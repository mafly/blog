﻿using System.Net;
using System.Web;
using Newtonsoft.Json;
using System.Web.Script.Serialization;

namespace ConsoleApplication1
{
    public class IPToLocation
    {
        public IPLocation GetLocationByTB(string ip)
        {
            if (string.IsNullOrEmpty(ip))
                return null;
            var webClient = new WebClient();
            var entity = webClient.DownloadString(string.Format("http://ip.taobao.com/service/getIpInfo.php?ip={0}",ip));
            var json = new JavaScriptSerializer().Deserialize<dynamic>(entity);
            if (json == null || json["code"] == 1)
                return GetLocationBySina(ip);    //调用其它接口
            var data = new JavaScriptSerializer().Serialize(json["data"]);
            IPLocation model = JsonConvert.DeserializeObject<IPLocation>(data);
            #region 传统方式实现
            //var model = new IPLocation();
            //model.IP = ip;
            //model.Country = HttpUtility.HtmlDecode(json["data"]["country"]);
            //model.CountryId = json["data"]["country_id"];
            //model.Area = json["data"]["area"];
            //return model.Country;
            #endregion
            return model;
        }

        public IPLocation GetLocationBySina(string ip)
        {
            if (string.IsNullOrEmpty(ip))
                return null;
            var webClient = new WebClient();
            var entity = webClient.DownloadString(string.Format("http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json&ip={0}", ip));
            if (entity == null)
                return GetLocationByTB(ip);
            var model = JsonConvert.DeserializeObject<IPLocation>(entity);
            return model;
        }
    }

    [JsonObject]
    public class IPLocation
    {
        [JsonProperty]
        public string IP { get; set; }
        [JsonProperty]
        public string Country { get; set; }
        [JsonProperty]
        public string Country_Id { get; set; }
        [JsonProperty]
        public string Area { get; set; }
        [JsonProperty]
        public int Area_Id { get; set; }
        [JsonProperty]
        public string Province { get; set; }
        [JsonProperty]
        public int Province_Id { get; set; }
        [JsonProperty]
        public string City { get; set; }
        [JsonProperty]
        public int City_Id { get; set; }
        [JsonProperty]
        public string District { get; set; }
        [JsonProperty]
        public int District_Id { get; set; }
        [JsonProperty]
        public string Isp { get; set; }
        [JsonProperty]
        public int Isp_Id { get; set; }
    }
}
